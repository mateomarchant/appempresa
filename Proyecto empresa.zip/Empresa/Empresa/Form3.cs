﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Empresa
{
    public partial class Form3 : Form
    {
        public double SueldoLiquidoForm2 { get; set; }
        public int SelectedIndexComboBox1Form2 { get; set; }

        public List<Form4.Persona> ClientesList { get; set; }
        public Form4.Persona ClienteSeleccionadoForm4 { get; set; }

        public Form3(List<Form4.Persona> clientes)
        {
            InitializeComponent();
            ClientesList = clientes;
            LlenarComboBox();
        }

        public void SetClientesList(List<Form4.Persona> clientes)
        {
            ClientesList = clientes;
            LlenarComboBox();
        }

        private void LlenarComboBox()
        {
            comboBox1.Items.Clear();

            foreach (var cliente in ClientesList)
            {
                comboBox1.Items.Add($"RUT: {cliente.Rut}");
            }

            comboBox1.SelectedIndex = comboBox1.Items.Count > 0 ? 0 : -1;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            dataGridView1.Columns.Add("Rut", "RUT");
            dataGridView1.Columns.Add("Nombre", "Nombre");
            dataGridView1.Columns.Add("Direccion", "Dirección");
            dataGridView1.Columns.Add("SueldoLiquido", "Sueldo Líquido");

            foreach (var cliente in ClientesList)
            {
                dataGridView1.Rows.Add(cliente.Rut, cliente.Nombre, cliente.Direccion, SueldoLiquidoForm2);
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                int rowIndex = dataGridView1.SelectedCells[0].RowIndex;

                DataGridViewRow selectedRow = dataGridView1.Rows[rowIndex];
                string rut = selectedRow.Cells["Rut"].Value.ToString();

                string nuevoNombre = Prompt.ShowDialog("Nuevo nombre para " + rut, "Modificar", selectedRow.Cells["Nombre"].Value.ToString());

                selectedRow.Cells["Nombre"].Value = nuevoNombre;

                MessageBox.Show("Nombre modificado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Selecciona un cliente para modificar su nombre.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        public static class Prompt
        {
            public static string ShowDialog(string text, string caption, string defaultValue = "")
            {
                Form prompt = new Form()
                {
                    Width = 500,
                    Height = 150,
                    FormBorderStyle = FormBorderStyle.FixedDialog,
                    Text = caption,
                    StartPosition = FormStartPosition.CenterScreen
                };
                Label textLabel = new Label() { Left = 50, Top = 20, Text = text };
                TextBox textBox = new TextBox() { Left = 50, Top = 50, Width = 400, Text = defaultValue };
                Button confirmation = new Button() { Text = "Aceptar", Left = 350, Width = 100, Top = 70, DialogResult = DialogResult.OK };
                confirmation.Click += (sender, e) => { prompt.Close(); };
                prompt.Controls.Add(textBox);
                prompt.Controls.Add(confirmation);
                prompt.Controls.Add(textLabel);
                prompt.AcceptButton = confirmation;

                return prompt.ShowDialog() == DialogResult.OK ? textBox.Text : defaultValue;
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                int rowIndex = dataGridView1.SelectedCells[0].RowIndex;

                DataGridViewRow selectedRow = dataGridView1.Rows[rowIndex];
                string rut = selectedRow.Cells["Rut"].Value.ToString();

                DialogResult result = MessageBox.Show("¿Estás seguro de que deseas eliminar el cliente con RUT " + rut + "?", "Confirmar eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    dataGridView1.Rows.RemoveAt(rowIndex);
                    EliminarClienteDeLaLista(rut);

                    MessageBox.Show("Cliente eliminado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Selecciona un cliente para eliminar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void EliminarClienteDeLaLista(string rut)
        {
           
            var clienteAEliminar = ClientesList.Find(cliente => cliente.Rut == rut);

            if (clienteAEliminar != null)
            {
                ClientesList.Remove(clienteAEliminar);
            }
        }
    }
}
