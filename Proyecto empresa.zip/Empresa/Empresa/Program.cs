﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Empresa
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Crear una lista de personas (clientes)
            List<Form4.Persona> clientesList = new List<Form4.Persona>();


            // Crear instancias de Form1 y Form3, pasando la lista de clientes a Form3
            Form1 form1 = new Form1();
            Form3 form3 = new Form3(clientesList);


            // Iniciar la aplicación desde Form1
            Application.Run(form1);
        }
    }
}
