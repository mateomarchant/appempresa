﻿// Form2
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Empresa
{
    public partial class Form2 : Form
    {
        public double SueldoLiquido { get { return sueldoLiquido; } }
        public int SelectedIndexComboBox1 { get { return comboBox1.SelectedIndex; } }

        public List<Form4.Persona> ClientesList { get; set; }

        int horasTrabajadas, horasExtras;
        double sueldoBruto, descuentoAFP, descuentoSalud, sueldoLiquido;

        public Form2(List<Form4.Persona> clientes)
        {
            InitializeComponent();
            ClientesList = clientes;
            LlenarComboBox();
        }

        public void SetClientesList(List<Form4.Persona> clientes)
        {
            ClientesList = clientes;
            LlenarComboBox();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(ClientesList);
            form2.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox3.SelectedIndex >= 0)
            {
                int selectedIndex = comboBox3.SelectedIndex;

                ClientesList[selectedIndex].SueldoBruto = sueldoBruto;
                ClientesList[selectedIndex].SueldoLiquido = sueldoLiquido;

                MessageBox.Show("Sueldo actualizado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Selecciona un cliente para actualizar su sueldo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LlenarComboBox()
        {
            comboBox1.Items.Clear();

            foreach (var cliente in ClientesList)
            {
                comboBox3.Items.Add($"RUT: {cliente.Rut}");
            }

            comboBox3.SelectedIndex = comboBox3.Items.Count > 0 ? 0 : -1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out horasTrabajadas) && int.TryParse(textBox2.Text, out horasExtras))
            {
                sueldoBruto = (horasTrabajadas * 5000) + (horasExtras * 7000);

                if (comboBox1.SelectedIndex >= 0)
                {
                    switch (comboBox1.SelectedItem?.ToString())
                    {
                        case "CUPRUM":
                            descuentoAFP = sueldoBruto * 0.07;
                            break;
                        case "MODELO":
                            descuentoAFP = sueldoBruto * 0.09;
                            break;
                        case "CAPITAL":
                            descuentoAFP = sueldoBruto * 0.12;
                            break;
                        case "PROVIDA":
                            descuentoAFP = sueldoBruto * 0.13;
                            break;
                    }
                }

                if (comboBox2.SelectedIndex >= 0)
                {
                    switch (comboBox2.SelectedItem?.ToString())
                    {
                        case "FONASA":
                            descuentoSalud = sueldoBruto * 0.12;
                            break;
                        case "CONSALUD":
                            descuentoSalud = sueldoBruto * 0.13;
                            break;
                        case "MASVIDA":
                            descuentoSalud = sueldoBruto * 0.14;
                            break;
                        case "BANMEDICA":
                            descuentoSalud = sueldoBruto * 0.15;
                            break;
                    }
                }

                textBox3.Text = sueldoBruto.ToString();

                double descuentoTotal = descuentoAFP + descuentoSalud;
                sueldoLiquido = sueldoBruto - descuentoTotal;

                textBox4.Text = sueldoLiquido.ToString();

            }
            else
            {
                MessageBox.Show("Por favor, ingresa valores válidos para horas trabajadas y horas extras.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            this.Load += Form2_Load;

            comboBox1.Items.Add("CUPRUM");
            comboBox1.Items.Add("MODELO");
            comboBox1.Items.Add("CAPITAL");
            comboBox1.Items.Add("PROVIDA");

            comboBox1.SelectedIndex = 0;

            comboBox2.Items.Add("FONASA");
            comboBox2.Items.Add("CONSALUD");
            comboBox2.Items.Add("MASVIDA");
            comboBox2.Items.Add("BANMEDICA");

            comboBox2.SelectedIndex = 0;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();

            horasTrabajadas = 0;
            horasExtras = 0;
            sueldoBruto = 0;
            descuentoAFP = 0;
            descuentoSalud = 0;
            sueldoLiquido = 0;

            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;

            MessageBox.Show("Campos limpiados", "Limpiar Campos", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
