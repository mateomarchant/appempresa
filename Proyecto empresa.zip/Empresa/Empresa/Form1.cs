﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Empresa
{
    public partial class Form1 : Form
    {
        private Dictionary<string, string> usuarios = new Dictionary<string, string>();
        private List<Form4.Persona> clientesList = new List<Form4.Persona>();

        public Form1()
        {
            InitializeComponent();
            usuarios.Add("admin", "1234");
            usuarios.Add("usuario", "1234");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string usuario = textBox1.Text;
            string contrasena = textBox2.Text;

            if (AutenticarUsuario(usuario, contrasena))
            {
                MessageBox.Show("Inicio de sesión exitoso");

                this.Hide();

                Form4 form4 = Application.OpenForms.OfType<Form4>().FirstOrDefault();
                if (form4 == null)
                {
                    Form3 form3 = new Form3(clientesList);
                    form4 = new Form4(form3);

                    form4.ShowDialog();
                }
            }
            else
            {
                MessageBox.Show("Error en el inicio de sesión. Verifica tu usuario y contraseña.");
            }
        }

        private bool AutenticarUsuario(string usuario, string contrasena)
        {
            if (usuarios.ContainsKey(usuario) && usuarios[usuario] == contrasena)
            {
                return true;
            }
            return false;
        }
    }
}
