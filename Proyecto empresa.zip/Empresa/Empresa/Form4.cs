﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Empresa
{
    public partial class Form4 : Form
    {
        public List<Persona> clientesList = new List<Persona>();

        public Form4(Form3 form3)
        {
            InitializeComponent();
            form3.SetClientesList(clientesList);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string mensajeError = ValidarCampos();

            if (!string.IsNullOrEmpty(mensajeError))
            {
                MessageBox.Show(mensajeError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                AgregarCliente();
            }
        }

        private string ValidarCampos()
        {
            if (!ValidaRut(textBox1.Text, textBox6.Text, out string errorRut))
            {
                return $"RUT inválido: {errorRut}";
            }
            else if (!ValidarNombre(textBox2.Text))
            {
                return "Nombre inválido: Debe ingresar un nombre válido.";
            }
            else if (!ValidarTelefono(textBox4.Text))
            {
                return "Teléfono inválido: Debe ingresar un teléfono válido en el formato +569.";
            }
            else if (string.IsNullOrEmpty(textBox4.Text))
            {
                return "Dirección inválida: Debe ingresar una dirección válida.";
            }
            else if (string.IsNullOrEmpty(textBox5.Text))
            {
                return "Apellido inválido: Debe ingresar un apellido válido.";
            }

            return string.Empty;
        }

        private void AgregarCliente()
        {
            Persona nuevoCliente = new Persona
            {
                Rut = textBox1.Text.Replace(".", "").ToUpper(),
                Nombre = textBox2.Text,
                Telefono = textBox3.Text,
                Direccion = textBox4.Text,
                Apellido = textBox5.Text,
                Dv = textBox6.Text.ToUpper()
            };

            clientesList.Add(nuevoCliente);

            LimpiarTextBox();

            MessageBox.Show("Persona guardada exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private bool ValidarNombre(string nombre)
        {
            return !string.IsNullOrEmpty(nombre);
        }

        private bool ValidaRut(string rut, string dv, out string mensajeError)
        {
            mensajeError = string.Empty;

            if (string.IsNullOrEmpty(rut))
            {
                mensajeError = "Debe ingresar un RUT válido.";
                return false;
            }

            if (!int.TryParse(rut, out _))
            {
                mensajeError = "La primera parte del RUT debe contener solo dígitos.";
                return false;
            }

            if (!Regex.IsMatch(dv, @"^(\d|K|k)$"))
            {
                mensajeError = "El formato del dígito verificador no es correcto.";
                return false;
            }

            int[] rutInt = rut.Select(c => int.Parse(c.ToString())).ToArray();
            int suma = rutInt.Reverse().Zip(new[] { 2, 3, 4, 5, 6, 7, 2, 3, 4, 5, 6, 7 }, (a, b) => a * b).Sum();
            int resto = suma % 11;
            int digitoEsperado = resto == 0 ? 0 : 11 - resto;

            if (dv.ToUpper() == "K" && digitoEsperado != 10)
            {
                mensajeError = "El dígito verificador K no es correcto.";
                return false;
            }

            if (dv.ToUpper() == "0" && digitoEsperado != 0)
            {
                mensajeError = "El dígito verificador 0 no es correcto.";
                return false;
            }

            if (dv.ToUpper() != "K" && dv.ToUpper() != "0" && digitoEsperado != int.Parse(dv))
            {
                mensajeError = "El dígito verificador ingresado no es correcto.";
                return false;
            }

            return true;
        }

        private void LimpiarTextBox()
        {
            foreach (Control control in Controls)
            {
                if (control is TextBox textBox)
                {
                    textBox.Clear();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3(clientesList);
            form3.Show();
        }

        public class Persona
        {
            public string Rut { get; set; }
            public string Nombre { get; set; }
            public string Telefono { get; set; }
            public string Direccion { get; set; }
            public string Apellido { get; set; }
            public string Dv { get; set; }
            public double SueldoBruto { get; set; }
            public double SueldoLiquido { get; set; }
        }

        private bool ValidarTelefono(string telefono)
        {
            if (string.IsNullOrEmpty(telefono) || telefono.Length != 12)
            {
                return false;
            }

            return telefono.StartsWith("+56") && telefono.Substring(3).All(char.IsDigit);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3(clientesList);
            form3.Show();
        }
    }
}
